# 🌐 Portfolio — Fatimata Walet Mohamed Ali

Portfolio bilingue FR/EN — Software Engineer · Communication Digitale · IT Manager

---

## 📁 Structure des fichiers

```
portfolio/
│
├── index.html              ← Redirection automatique vers /fr/
│
├── fr/
│   └── index.html          ← Version française (PRINCIPALE)
│
├── en/
│   └── index.html          ← Version anglaise
│
└── assets/
    └── CV_Fatimata_Walet_Mohamed_Ali.pdf   ← Ton CV (à ajouter !)
```

---

## 🚀 Étapes avant mise en ligne

### 1. Ajouter ta photo
Dans `fr/index.html` et `en/index.html`, remplace le bloc `.hero-photo-placeholder` par :
```html
<img src="../assets/photo.jpg" alt="Fatimata Walet Mohamed Ali" style="width:100%;height:100%;object-fit:cover;position:relative;z-index:1;" />
```
Place ta photo dans `assets/photo.jpg`.

### 2. Ajouter ton CV PDF
Place ton fichier CV dans :
```
assets/CV_Fatimata_Walet_Mohamed_Ali.pdf
```

### 3. Configurer Formspree (contact form)
1. Va sur https://formspree.io et crée un compte gratuit
2. Crée un nouveau formulaire avec ton email
3. Copie ton **Form ID** (ex: `xpzgkwvb`)
4. Dans `fr/index.html` et `en/index.html`, remplace :
   ```
   https://formspree.io/f/VOTRE_ID_FORMSPREE
   ```
   par :
   ```
   https://formspree.io/f/xpzgkwvb
   ```

### 4. Mettre à jour les URLs du QR Code
Dans le script de chaque fichier, l'URL du QR code est générée automatiquement depuis `window.location.origin`.
Si tu veux forcer une URL fixe, remplace dans le script :
```js
text: window.location.origin + '/assets/CV_Fatimata_Walet_Mohamed_Ali.pdf',
```
par :
```js
text: 'https://ton-domaine.com/assets/CV_Fatimata_Walet_Mohamed_Ali.pdf',
```

---

## 🟣 Hébergement sur GitHub Pages

1. Crée un repository GitHub (ex: `fatimata-walet.github.io`)
2. Upload tout le contenu du dossier `portfolio/` à la racine du repo
3. Va dans **Settings → Pages → Source → main branch / root**
4. Ton site sera disponible sur : `https://fatimata-walet.github.io`

**Structure sur GitHub :**
```
repository root/
├── index.html
├── fr/index.html
├── en/index.html
└── assets/
    └── CV_Fatimata_Walet_Mohamed_Ali.pdf
```

---

## 🟠 Hébergement sur Hostinger

1. Connecte-toi à ton panel Hostinger
2. Va dans **File Manager → public_html**
3. Upload le contenu du dossier `portfolio/` dans `public_html/`
4. Ton site sera disponible sur ton domaine personnalisé

---

## ✅ Checklist avant mise en ligne

- [ ] Photo ajoutée dans `assets/photo.jpg`
- [ ] CV PDF ajouté dans `assets/CV_Fatimata_Walet_Mohamed_Ali.pdf`
- [ ] ID Formspree remplacé dans `fr/index.html`
- [ ] ID Formspree remplacé dans `en/index.html`
- [ ] URL du QR code mise à jour avec ton domaine réel
- [ ] Lien LinkedIn vérifié
- [ ] Numéro de téléphone vérifié
- [ ] Adresse email vérifiée

---

## 🎨 Personnalisation rapide

Les couleurs sont centralisées dans les variables CSS en haut de chaque fichier :
```css
:root {
  --terracotta: #c4602a;  /* Couleur principale */
  --gold:       #b8963e;  /* Couleur accent */
  --ink:        #0d0d0d;  /* Noir principal */
  --ivory:      #f5f0e8;  /* Fond principal */
}
```

---

**© 2025 Fatimata Walet Mohamed Ali**
